package com.example.servingwebcontent

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ServingWebContentApplication

fun main(args: Array<String>) {
	runApplication<ServingWebContentApplication>(*args)
}
